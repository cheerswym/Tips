#include <iostream>

using namespace std;

bool QuinticParametersSolver(double stx, double sty, double st_r, double st_dr,
                             double endx, double endy, double end_r,
                             double end_dr, Eigen::VectorXf &param) {
  // curvature K = y''/( 1 + y'_2)_(1.5)
  // K1 = st_dr/vel, K2 = end_dr/vel
  if (std::fabs(stx - endx) < 0.01) {
    NM_ERROR("the lenght of input is too short, QuinticFit fail");
    return false;
  }
  if (stx >= endx) {
    NM_ERROR("stx >= endx, QuinticFit fail");
    return false;
  }
  st_r = tan(st_r);
  end_r = tan(end_r);
  // NM_DEBUG("QuinticFit step 1");
  Eigen::MatrixXf A(6, 6);
  double one, two, three, four, five;
  one = stx;
  two = one * one;
  three = two * one;
  four = three * one;
  five = four * one;
  Eigen::MatrixXf t(3, 6);
  t << five, four, three, two, one, 1, 5 * four, 4 * three, 3 * two, 2 * one, 1,
      0, 20 * three, 12 * two, 6 * one, 2, 0, 0;
  // NM_DEBUG("QuinticFit step 2");
  one = endx;
  two = one * one;
  three = two * one;
  four = three * one;
  five = four * one;
  Eigen::MatrixXf h(3, 6);
  h << five, four, three, two, one, 1, 5 * four, 4 * three, 3 * two, 2 * one, 1,
      0, 20 * three, 12 * two, 6 * one, 2, 0, 0;
  // NM_DEBUG("QuinticFit step 3");
  A << t, h;
  Eigen::VectorXf B(6);
  // NM_DEBUG("QuinticFit step 4");
  double tem = st_r * st_r + 1;
  tem = std::sqrt(tem * tem * tem);
  double dyy1 = st_dr * (tem);
  tem = end_r * end_r + 1;
  tem = std::sqrt(tem * tem * tem);
  double dyy2 = end_dr * (tem);
  B << sty, st_r, dyy1, endy, end_r, dyy2;
  param = A.inverse() * B;
  if (param.rows() == 0 || param.cols() == 0) {
    NM_DEBUG("in QuinticFit, param is empty, QuinticFit fail");
    std::ostringstream stream;
    stream << "A: " << A << std::endl << "B: " << B;
    NM_DEBUG(stream.str());
    return false;
  }
  bool ok = true;
  for (int i = 0; i < 6; i++) {
    if (std::isnan(param(i)) || std::isinf(param(i))) {
      ok = false;
      break;
    }
  }
  if (!ok) {
    NM_DEBUG("in QuinticFit, get inv of A fail, check input");
    std::ostringstream stream;
    stream << "A: " << A << std::endl << "B: " << B;
    NM_DEBUG(stream.str());
    return false;
  }
  return ok;
}
