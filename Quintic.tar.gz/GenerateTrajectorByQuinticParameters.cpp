#include <iostream>
#include <cmath>

bool GenerateTrajectorByQuinticParameters(Eigen::VectorXf &param, double stx,
                                          double sty, double st_r, double st_k,
                                          double endx, double endy,
                                          double min_interval,
                                          double maximum_base_waypoint_length,
                                          Trajectory &way) {
  double tx = stx, ty = sty, tr = st_r, kk = st_k;
  double s = 0.0;
  double rc4 = param(0) * 5, rc3 = param(1) * 4, rc2 = param(2) * 3,
         rc1 = param(3) * 2, rc0 = param(4);
  // NM_DEBUG("QuinticFit step 5");
  NM_DEBUG("quintic param:(C5~C0): {} {} {} {} {} {} min_interval: {}",
           param(0), param(1), param(2), param(3), param(4), param(5),
           min_interval);
  tx = stx;
  ty = sty, tr = tan(st_r);
  double te;
  // K = y''/( 1 + y'_2)_(1.5)
  auto max_allowed_size = (fabs(endx - stx) + fabs(endy - sty)) / min_interval;
  auto max_trajectory_size = maximum_base_waypoint_length / min_interval;
  max_allowed_size = std::min(max_allowed_size, max_trajectory_size);
  while (true) {
    if (tx <= endx) {
      auto wp = way.add_waypoints();
      wp->set_x(tx);
      wp->set_y(ty);
      wp->set_r(atan(tr));
      wp->set_curvature(kk);
      wp->set_s(s);
      tx = tx + min_interval / std::sqrt(1 + tr * tr);  // next x
      ty = util::Quintic(tx, param(0), param(1), param(2), param(3), param(4),
                         param(5));                     // next y
      tr = util::Quartic(tx, rc4, rc3, rc2, rc1, rc0);  // next_r
      te = 1 + tr * tr;
      te = sqrt(te * te * te);
      kk = util::Cubic(tx, 4 * rc4, 3 * rc3, 2 * rc2, rc1) / te;  // next K
      s += std::hypot(tx - wp->x(), ty - wp->y());
    } else {
      break;
    }
    if (max_allowed_size < 0) {
      return false;
    }
    --max_allowed_size;
  }
  return true;
}
